#include "lab02.h"

#include <xc.h>
#include <p33Fxxxx.h>
//do not change the order of the following 2 definitions
#define FCY 12800000UL
#include <libpic30.h>

#include "types.h"
#include "lcd.h"
#include "led.h"

#define FCY_EXT 32768

volatile unsigned int minutes = 0;
volatile unsigned int seconds = 0;
volatile unsigned int milliseconds = 0;


void initialize_timer()
{
    // Enable RTC Oscillator -> this effectively does OSCCONbits.LPOSCEN = 1
    // but the OSCCON register is lock protected. That means you would have to 
    // write a specific sequence of numbers to the register OSCCONL. After that 
    // the write access to OSCCONL will be enabled for one instruction cycle.
    // The function __builtin_write_OSCCONL(val) does the unlocking sequence and
    // afterwards writes the value val to that register. (OSCCONL represents the
    // lower 8 bits of the register OSCCON)
     
    // initialize timer 1
    __builtin_write_OSCCONL(OSCCONL | 2); // Enable RTC Oscillator
    CLEARBIT(T1CONbits.TON); // Disable the Timers
    T1CONbits.TCKPS = 0b11; // Set Prescaler 
    SETBIT(T1CONbits.TCS); // Set Clock Source   
    CLEARBIT(T1CONbits.TGATE); // Set Gated Timer Mode -> don't use gating   
    CLEARBIT(T1CONbits.TSYNC); // T1: Set External Clock Input Synchronization -> no sync
    PR1 = 125; // Load Timer Periods
    TMR1 = 0X00;  // Reset Timer Values
    IPC0bits.T1IP = 0x01; // Set Interrupt Priority
    CLEARBIT(IFS0bits.T1IF); // Clear Interrupt Flags
    SETBIT(IEC0bits.T1IE); // Enable Interrupts
    SETBIT(T1CONbits.TON); // Enable the Timers
    
    // initialize timer 2
    CLEARBIT(T2CONbits.TON);
    T2CONbits.TCKPS = 0b11;
    CLEARBIT(T2CONbits.TCS);
    CLEARBIT(T2CONbits.TGATE);
    PR2 = 100;
    TMR2 = 0X00;
    IPC1bits.T2IP = 0x01;
    CLEARBIT(IFS0bits.T2IF);
    SETBIT(IEC0bits.T2IE);
    SETBIT(T2CONbits.TON);
    
    // initialize timer 3
    CLEARBIT(T3CONbits.TON); // Disable Timer 3
	T3CONbits.TCKPS = 0b00; // Set Timer 3 prescaler to 1:1
    CLEARBIT(T3CONbits.TCS); // Select internal instruction cycle clock
    CLEARBIT(T3CONbits.TGATE); // Disable Gated Timer mode
    PR3 = 0xFFFF; // Max period value
    TMR3 = 0x00; // Clear timer 3 register
}


void timer_loop()
{
    // print assignment information
    lcd_printf("Lab02: Int & Timer");
    lcd_locate(0,1);
    lcd_printf("Group: Session2Group3");

    unsigned int loopCount = 0;
    double milliseconds_Timer3; 
    
    SETBIT(T3CONbits.TON); // Start Timer 3
    
    while(TRUE)
    {
        loopCount++;
        
        if (loopCount % 2000 == 0){
            
            lcd_locate(0,6);
            lcd_printf("%02d:%02d.%03d", minutes, seconds, milliseconds);
            
            TOGGLELED(LED3_PORT); // Toggle LED 3
            
            loopCount = 0;
            
            milliseconds_Timer3 = (TMR3 / 12.8e6) * 1000;
            
            lcd_locate(0,7);
            lcd_printf("C:%d, T:%.4fms", TMR3, milliseconds_Timer3);
            
            TMR3 = 0;

        }
        
    }
}

void __attribute__((__interrupt__, __shadow__, __auto_psv__)) _T1Interrupt(void)
{ // invoked every ??
    CLEARBIT(IFS0bits.T1IF); 
    TOGGLELED(LED2_PORT);
    seconds++;
    if (seconds == 60){
        minutes++;
        seconds = 0;
    }
}

void __attribute__((__interrupt__, __shadow__, __auto_psv__)) _T2Interrupt(void)
{ // invoked every ??

    CLEARBIT(IFS0bits.T2IF);  
    TOGGLELED(LED1_PORT);
    milliseconds += 2;
    if (milliseconds == 1000){
        milliseconds = 0;
    }
}
