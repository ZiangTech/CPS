#include <xc.h>
#include <p33Fxxxx.h>
//do not change the order of the following 2 definitions
#define FCY 12800000UL 
#include <libpic30.h>

#include "lcd.h"
#include "led.h"
#include "lab02.h"

/* Configuration of the Chip */
// Initial Oscillator Source Selection = Primary (XT, HS, EC) Oscillator with PLL
#pragma config FNOSC = PRIPLL
// Primary Oscillator Mode Select = XT Crystal Oscillator mode
#pragma config POSCMD = XT
// OSC2 Pin Function: OSC2 is Clock Output
#pragma config OSCIOFNC = ON
// Watchdog Timer Enable = Watchdog Timer enabled/disabled by user software
// (LPRC can be disabled by clearing the SWDTEN bit in the RCON register)
#pragma config FWDTEN = OFF

int main(){
    //Init LCD and LEDs
    lcd_initialize();
    led_init();
	
    // Clear the Screen and reset the cursor
    lcd_clear();
    lcd_locate(0, 0);
    
    // Initialize Lab 02 Timers
    initialize_timer();
    
    // Start Lab02 Main Program
    timer_loop();
    
    /*
    // Timer 3 configuration
	
    
    
    // Measure Execution Time for 2000 Loop Iterations
    unsigned int startTime = TMR3; 
    
    int i = 0;
    
    for (i = 0; i < 2000; i++) {
    }
    
    unsigned int endTime = TMR3;
    
    CLEARBIT(T3CONbits.TON); // Stop Timer 3 after measurement
    
    
    unsigned int cycles;
    
    if (endTime >= startTime) {
        cycles = endTime - startTime;
    } 
    else {
        unsigned int ZerotoMax = 0xFFFF - startTime; // Cycles from start to max timer value
        unsigned int ZerotoEnd = endTime + 1;      // Cycles from zero to end
        cycles = ZerotoMax + ZerotoEnd;               // Total cycles considering overflow
    }

    double milliseconds_Timer3 = (cycles / 12.8e6) * 1000;
    
    lcd_locate(0,7);

    // char result[30];
    // sprintf(result, "C:%u, T:%.4fms", cycles, milliseconds_Timer3);
    lcd_printf("C:%u, T:%.4f ms", cycles, milliseconds_Timer3);
    // lcd_printf("%s", result); // Print to buffer
    // fflush(); // Flush to LCD

    
    */
    
    // Stop
    while(1)
        ;
}

