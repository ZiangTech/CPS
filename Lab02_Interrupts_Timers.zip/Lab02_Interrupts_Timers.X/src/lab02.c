#include "lab02.h"

#include <xc.h>
#include <p33Fxxxx.h>
//do not change the order of the following 2 definitions
#define FCY 12800000UL
#include <libpic30.h>

#include "types.h"
#include "lcd.h"
#include "led.h"

#define FCY_EXT 32768

volatile unsigned int global_counter_T1 = 0;
volatile unsigned int global_counter_T2 = 0;
volatile unsigned int loopCount = 0;

void initialize_timer1()
{
    // Enable RTC Oscillator -> this effectively does OSCCONbits.LPOSCEN = 1
    // but the OSCCON register is lock protected. That means you would have to 
    // write a specific sequence of numbers to the register OSCCONL. After that 
    // the write access to OSCCONL will be enabled for one instruction cycle.
    // The function __builtin_write_OSCCONL(val) does the unlocking sequence and
    // afterwards writes the value val to that register. (OSCCONL represents the
    // lower 8 bits of the register OSCCON)
    __builtin_write_OSCCONL(OSCCONL | 2);
    // Disable the Timers
    CLEARBIT(T1CONbits.TON);
    // Set Prescaler
    T1CONbits.TCKPS = 0b11;
    // Set Clock Source
    SETBIT(T1CONbits.TCS);
    // Set Gated Timer Mode -> don't use gating
    CLEARBIT(T1CONbits.TGATE);
    // T1: Set External Clock Input Synchronization -> no sync
    CLEARBIT(T1CONbits.TSYNC);
    // Load Timer Periods
    PR1 = 125;
    // Reset Timer Values
    TMR1 = 0X00;
    // Set Interrupt Priority
    IPC0bits.T1IP = 0x02;
    // Clear Interrupt Flags
    CLEARBIT(IFS0bits.T1IF);
    // Enable Interrupts
    SETBIT(IEC0bits.T1IE);
    // Enable the Timers
    SETBIT(T1CONbits.TON);
}

void initialize_timer2()
{
    CLEARBIT(T2CONbits.TON);
    T2CONbits.TCKPS = 0b11;
    CLEARBIT(T2CONbits.TCS);
    CLEARBIT(T2CONbits.TGATE);
    PR2 = 100;
    TMR2 = 0X00;
    IPC1bits.T2IP = 0x01;
    CLEARBIT(IFS0bits.T2IF);
    SETBIT(IEC1bits.T2IE);
    SETBIT(T2CONbits.TON);
}


void timer_loop()
{
    // print assignment information
    lcd_printf("Lab02: Int & Timer");
    lcd_locate(0, 1);
    lcd_printf("Group: Session2-Group3");
    
    while(TRUE)
    {
        loopCount++;
        
        if (loopCount % 2000 == 0){
            unsigned int minutes = 0;
            
        }
        
        lcd_locate(0,4);
        
    }
}

void __attribute__((__interrupt__, __shadow__, __auto_psv__)) _T1Interrupt(void)
{ // invoked every ??
    global_counter_T1++;
    CLEARBIT(IFS0bits.T1IF); 
    TOGGLELED(LED2_PORT);
}

void __attribute__((__interrupt__, __shadow__, __auto_psv__)) _T2Interrupt(void)
{ // invoked every ??
    global_counter_T2++;
    CLEARBIT(IFS0bits.T2IF);  
    TOGGLELED(LED1_PORT);
}
